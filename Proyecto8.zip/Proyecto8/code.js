var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7544f7e0-ae24-4d19-a2f3-f8df1198e013","692a3dfe-4368-4574-a340-ca71d9afeb75","0bdcb33c-7061-416e-ab7e-f20d955a9bdc"],"propsByKey":{"7544f7e0-ae24-4d19-a2f3-f8df1198e013":{"name":"ball","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"chTr.YKAvZPM1q4emWvFez23UEH6hPzg","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/7544f7e0-ae24-4d19-a2f3-f8df1198e013.png"},"692a3dfe-4368-4574-a340-ca71d9afeb75":{"name":"robot_1","categories":["icons"],"frameCount":1,"frameSize":{"x":273,"y":393},"looping":true,"frameDelay":12,"jsonLastModified":"2021-01-05 19:20:46 UTC","pngLastModified":"2021-01-05 19:20:27 UTC","version":"tjAmWVbu.vnrfzW4WN4CvkdYe1.UiIon","sourceUrl":null,"sourceSize":{"x":273,"y":393},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/692a3dfe-4368-4574-a340-ca71d9afeb75.png"},"0bdcb33c-7061-416e-ab7e-f20d955a9bdc":{"name":"caballero","categories":["fantasy"],"frameCount":1,"frameSize":{"x":264,"y":243},"looping":true,"frameDelay":12,"jsonLastModified":"2021-01-05 19:06:42 UTC","pngLastModified":"2021-01-05 19:07:54 UTC","version":"AyLDjZicHYUleWuWL4RngmbsgFmnkvMq","sourceUrl":null,"sourceSize":{"x":264,"y":243},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/0bdcb33c-7061-416e-ab7e-f20d955a9bdc.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var playerMallet;

var goal1=createSprite(200,18,100,20);
goal1.shapeColor=("yellow");

var goal2=createSprite(200,382,100,20);
goal2.shapeColor=("yellow");

var gameState = "serve";

var boundary1 = createSprite(200,0,400,10);
boundary1.shapeColor = "white";
var boundary2 = createSprite(200,400,400,10);
boundary2.shapeColor = "white";
var boundary3 = createSprite(0,200,10,400);
boundary3.shapeColor = "white";
var boundary4 = createSprite(400,200,10,400);
boundary4.shapeColor = "white";

var striker = createSprite(200,200,10,10);
striker.shapeColor = "white";
striker.setAnimation("ball"); 
striker.scale=0.9; 

var playerMallet = createSprite(200,50,50,10);
playerMallet.setAnimation("caballero");
playerMallet.scale=0.2;
 
var computerMallet = createSprite(200,335,50,10);
computerMallet.setAnimation("robot_1");
computerMallet.scale=0.2;

var playerScore=0;
var compScore=0;

function draw() {
  background("green");
  
  if(gameState=="serve")
  {

textSize(18);
 fill ("maroon");
text("Presione la barra espaciadora para atacar",40,180);
if (keyDown("space")) {
serve();
gameState="play";
}
}
textSize(18);
fill("maroon");
text(compScore, 25,225);
text(playerScore,25,185);
  
if(striker.isTouching(goal1))
{ 
compScore = compScore + 1;
striker.x=200;
striker.y=200;
striker.velocityX=0;
striker.velocityY=0;
}
if(striker.isTouching(goal2))
{
playerScore = playerScore + 1;
striker.x=200;
striker.y=200;
striker.velocityX=0;
striker.velocityY=0;
}
if(playerScore==1 || compScore==1)
{
fill("maroon");
textSize(18);
text("Game Over!",170,160);
}
paddleMovement();
computerMallet.x = striker.x;

for (var i = 0; i < 400; i=i+20) {
line(i,200,i+10,200);
  }
createEdgeSprites();
  
striker.bounceOff(edges);
striker.bounceOff(playerMallet);
striker.bounceOff(computerMallet);
playerMallet.bounceOff(edges);
computerMallet.bounceOff(edges);

 drawSprites();
}

function serve() {
striker.velocityX = 10;
striker.velocityY = 15;
 
}

function paddleMovement()
{
if(keyDown("left")){
playerMallet.x = playerMallet.x-10;
  }
if(keyDown("right")){
playerMallet.x = playerMallet.x+10;
}
if(keyDown("up")){
if(playerMallet.y>25)
{
playerMallet.y = playerMallet.y- 10;
}
}
if(keyDown("down")){
if(playerMallet.y<120)
{
playerMallet.y = playerMallet.y+10;
}
}
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
